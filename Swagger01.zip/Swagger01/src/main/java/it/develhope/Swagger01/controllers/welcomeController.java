package it.develhope.Swagger01.controllers;

import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public class welcomeController {

    @GetMapping("")
    @ApiOperation(value = "Say hi to visitors")
    public String welcomeString(){
        return "Welcome to the home";
    }
}
